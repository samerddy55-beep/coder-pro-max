
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List
import uvicorn
from models import Product, Order
from database import db

app = FastAPI(title="متجر Coder Pro API", version="1.0.0")

app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

class ProductCreate(BaseModel):
    name: str
    price: float
    description: str = ""

@app.get("/")
def home():
    return {"message": "API متجر Coder Pro شغال 🔥", "version": "1.0.0", "endpoints": ["/products", "/orders"]}

@app.get("/products", response_model=List[Product])
def get_products():
    return db.get_products()

@app.post("/products")
def create_product(product: ProductCreate):
    new_product = db.create_product(product.dict())
    return new_product

@app.get("/products/{product_id}")
def get_product(product_id: int):
    product = db.get_product(product_id)
    if not product:
        raise HTTPException(status_code=404, detail="المنتج غير موجود")
    return product

@app.post("/orders")
def create_order(product_ids: List[int]):
    total = db.calculate_total(product_ids)
    order = db.create_order(product_ids, total)
    return {"order_id": order["id"], "total": total, "status": "تم الطلب بنجاح"}

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
