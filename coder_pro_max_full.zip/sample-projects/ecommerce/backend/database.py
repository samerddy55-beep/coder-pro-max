
# قاعدة بيانات مؤقتة - تقدر تستبدلها بـ PostgreSQL
class Database:
    def __init__(self):
        self.products = [
            {"id": 1, "name": "لابتوب برمجة", "price": 1200, "description": "للمبرمجين المحترفين"},
            {"id": 2, "name": "كيبورد", "price": 150, "description": "ميكانيكي RGB"},
        ]
        self.orders = []
    
    def get_products(self):
        return self.products
    
    def get_product(self, id):
        return next((p for p in self.products if p["id"] == id), None)
    
    def create_product(self, data):
        new_id = len(self.products) + 1
        product = {"id": new_id, **data}
        self.products.append(product)
        return product
    
    def calculate_total(self, ids):
        return sum(p["price"] for p in self.products if p["id"] in ids)
    
    def create_order(self, ids, total):
        order = {"id": len(self.orders)+1, "product_ids": ids, "total": total}
        self.orders.append(order)
        return order

db = Database()
