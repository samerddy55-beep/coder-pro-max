
from pydantic import BaseModel
from typing import List, Optional
from datetime import datetime

class Product(BaseModel):
    id: int
    name: str
    price: float
    description: str = ""
    image: str = ""
    created_at: datetime = datetime.now()

class Order(BaseModel):
    id: int
    product_ids: List[int]
    total: float
    status: str = "pending"
    created_at: datetime = datetime.now()

class User(BaseModel):
    id: int
    username: str
    email: str
    hashed_password: str
