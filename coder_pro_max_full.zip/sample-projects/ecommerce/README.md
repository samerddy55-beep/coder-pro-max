
# متجر Coder Pro - مشروع كامل

## التشغيل المحلي
```bash
# Backend
cd backend
pip install -r ../requirements.txt
uvicorn main:app --reload --port 8000

# Frontend
cd frontend
# افتح index.html في المتصفح أو:
python -m http.server 3000
```

## هيكل الملفات
- frontend/index.html - الواجهة
- frontend/style.css - التصميم
- frontend/app.js - المنطق
- backend/main.py - API
- backend/models.py - النماذج
- backend/database.py - قاعدة البيانات
