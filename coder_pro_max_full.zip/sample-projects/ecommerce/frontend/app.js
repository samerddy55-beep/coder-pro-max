
const products = [
  {id:1, name:"لابتوب برمجة", price:1200, img:""},
  {id:2, name:"كيبورد ميكانيكي", price:150, img:""},
  {id:3, name:"شاشة 4K", price:400, img:""},
  {id:4, name:"ماوس احترافي", price:80, img:""},
  {id:5, name:"سماعات", price:120, img:""},
  {id:6, name:"SSD 1TB", price:100, img:""}
];
let cart = [];
function renderProducts(){
  const container = document.getElementById('products');
  container.innerHTML = products.map(p => `
    <div class="product">
      <div style="height:180px;background:linear-gradient(135deg,#222,#333);border-radius:12px;display:flex;align-items:center;justify-content:center">🖥️</div>
      <h3>${p.name}</h3>
      <div class="price">$${p.price}</div>
      <button onclick="addToCart(${p.id})">أضف للسلة</button>
    </div>
  `).join('');
}
function addToCart(id){
  const product = products.find(p=>p.id===id);
  cart.push(product);
  document.getElementById('cart-count').textContent = cart.length;
  alert(`تمت إضافة ${product.name}`);
}
function checkout(){
  alert(`تم الطلب! المجموع: $${cart.reduce((s,p)=>s+p.price,0)} - شكرا من Coder Pro Max`);
  cart=[]; document.getElementById('cart-count').textContent=0;
}
renderProducts();
